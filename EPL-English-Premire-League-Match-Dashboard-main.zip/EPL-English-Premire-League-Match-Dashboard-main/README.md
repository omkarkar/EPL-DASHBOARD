# EPL-English-Premire-League-Match-Dashboard

Executed Academic project to create EPL match Dashboard using powerbi tool to get insight about the results of matches.
